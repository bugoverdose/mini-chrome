const { initApp } = require("./app");
const { initMenu } = require("./logic/menu");

initMenu();
initApp();
