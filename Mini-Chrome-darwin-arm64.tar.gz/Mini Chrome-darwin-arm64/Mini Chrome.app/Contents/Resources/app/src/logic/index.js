const ui = {
  ...require("./view"),
  ...require("./window"),
};

module.exports = ui;
