const page = {
  ...require("./header"),
  ...require("./fail"),
  ...require("./new"),
};

module.exports = page;
