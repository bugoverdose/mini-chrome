const state = {
  windows: new Set(),
  tabId: 0,
};

module.exports = state;
