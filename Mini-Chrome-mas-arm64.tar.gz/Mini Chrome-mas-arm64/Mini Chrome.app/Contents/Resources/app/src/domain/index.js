const data = {
  ...require("./window"),
  ...require("./tab"),
};

module.exports = data;
